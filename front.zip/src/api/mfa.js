import axios from 'axios';

const API = axios.create({ 
    baseURL: 'http://localhost:8000',
    headers: {
        'Content-Type': 'application/json',
    }
});

// Add request interceptor to include JWT token if available
API.interceptors.request.use((config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// Auth endpoints
export const loginUser = (username, password) => API.post('/auth/login', { username, password });
export const registerUser = (data) => API.post('/auth/register', data);
export const verifyMFA = (data) => API.post('/auth/verify-mfa', data);

// MFA endpoints
export const gridAuth = (gridData) => API.post('/mfa/verify-grid', gridData);
// export const faceAuth = (faceData) => API.post('/face/verify-face', { face: faceData });