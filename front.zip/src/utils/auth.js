// src/utils/auth.js

/**
 * Check if JWT token exists and is not expired
 * @returns {boolean} true if token is valid, false otherwise
 */
export const isTokenValid = () => {
  const token = localStorage.getItem('access_token');
  
  if (!token) {
    return false;
  }

  try {
    // Decode JWT token (without verification for client-side check)
    const payload = JSON.parse(atob(token.split('.')[1]));
    
    // Check if token is expired
    const currentTime = Date.now() / 1000;
    
    if (payload.exp && payload.exp < currentTime) {
      // Token is expired, remove it
      localStorage.removeItem('access_token');
      return false;
    }
    
    return true;
  } catch (error) {
    // Invalid token format, remove it
    localStorage.removeItem('access_token');
    return false;
  }
};

/**
 * Get the current JWT token
 * @returns {string|null} token if exists, null otherwise
 */
export const getToken = () => {
  return localStorage.getItem('access_token');
};

/**
 * Remove the JWT token (logout)
 */
export const removeToken = () => {
  localStorage.removeItem('access_token');
};

/**
 * Set the JWT token
 * @param {string} token - JWT token to store
 */
export const setToken = (token) => {
  localStorage.setItem('access_token', token);
};
  