import { Routes, Route, Navigate } from "react-router-dom";
import { isTokenValid } from "./utils/auth";
import "./App.css";
import LoginPage from "./pages/LoginPage.jsx";
import RegisterPage from "./pages/RegisterPage.jsx";
import CoordinatesDisplayPage from "./pages/CoordinatesDisplayPage.jsx";
import GridAuthPage from "./pages/GridAuthPage.jsx";
import FaceAuthPage from "./pages/FaceAuthPage.jsx";
import FaceRegisterPage from "./pages/FaceRegisterPage.jsx";
import HomePage from "./pages/HomePage.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";

function App() {
  // Component to handle root path redirection based on auth status
  const RootRedirect = () => {
    return isTokenValid() ? <Navigate to="/home" replace /> : <Navigate to="/login" replace />;
  };

  // Component to redirect authenticated users away from auth pages
  const AuthRedirect = ({ children }) => {
    return isTokenValid() ? <Navigate to="/home" replace /> : children;
  };

  return (
    <Routes>
      <Route path="/" element={<RootRedirect />} />
      <Route 
        path="/login" 
        element={
          <AuthRedirect>
            <LoginPage />
          </AuthRedirect>
        } 
      />
      <Route 
        path="/register" 
        element={
          <AuthRedirect>
            <RegisterPage />
          </AuthRedirect>
        } 
      />
      <Route 
        path="/coordinates" 
        element={
          <AuthRedirect>
            <CoordinatesDisplayPage />
          </AuthRedirect>
        } 
      />
      <Route 
        path="/grid-auth" 
        element={
          <AuthRedirect>
            <GridAuthPage />
          </AuthRedirect>
        } 
      />
      <Route 
        path="/face-register" 
        element={
          <AuthRedirect>
            <FaceRegisterPage />
          </AuthRedirect>
        } 
      />
      <Route 
        path="/face-auth" 
        element={
          <AuthRedirect>
            <FaceAuthPage />
          </AuthRedirect>
        } 
      />
      <Route 
        path="/home" 
        element={
          <ProtectedRoute>
            <HomePage />
          </ProtectedRoute>
        } 
      />
    </Routes>
  );
}

export default App;

