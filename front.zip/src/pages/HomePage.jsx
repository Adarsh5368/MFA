// src/pages/HomePage.js
import { useNavigate } from "react-router-dom";
import { removeToken } from "../utils/auth";
import "../styles/HomePage.css";

const HomePage = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    removeToken();
    navigate("/login");
  };

  return (
    <div className="home-container">
      <div className="home-card">
        <h2 className="home-title">Welcome to the Secure MFA Home Page</h2>
        <p className="home-message">
          <span className="success-icon">🎉</span>
          You are fully authenticated!
        </p>
        <button 
          onClick={handleLogout}
          className="logout-button"
          style={{
            marginTop: "20px",
            padding: "10px 20px",
            backgroundColor: "#dc3545",
            color: "white",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
            fontSize: "16px"
          }}
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default HomePage;
