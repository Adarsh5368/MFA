import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { gridAuth } from "../api/mfa";
import { setToken } from "../utils/auth";
import "../styles/GridAuthPage.css";

const GridAuthPage = () => {
  const [challenge, setChallenge] = useState({});
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);
  const [gridData, setGridData] = useState({});
  const [inputValue1, setInputValue1] = useState("");
  const [inputValue2, setInputValue2] = useState("");
  const [inputValue3, setInputValue3] = useState("");
  const [requiredCoordinates, setRequiredCoordinates] = useState([]);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const userData = location.state;

    if (userData) {
      // Handle different possible data structures
      if (userData.required_coordinates && userData.username) {
        // Case 1: Backend returns required_coordinates array
        const challengeObj = {};
        userData.required_coordinates.forEach(coord => {
          challengeObj[coord] = ""; // We'll populate this with actual grid values
        });
        setChallenge(challengeObj);
        setUsername(userData.username);
        setRequiredCoordinates(userData.required_coordinates);
        const grid = generateGrid(challengeObj);
        setGridData(grid);
      } else if (userData.challenge && userData.username) {
        // Case 2: Challenge object already exists
        setChallenge(userData.challenge);
        setUsername(userData.username);
        const coords = Object.keys(userData.challenge);
        setRequiredCoordinates(coords);
        const grid = generateGrid(userData.challenge);
        setGridData(grid);
      } else if (userData.username) {
        // Case 3: Only username, create a default challenge for testing
        const defaultChallenge = {
          "A1": "",
          "B3": "",
          "C5": ""
        };
        const defaultCoords = ["A1", "B3", "C5"];
        setChallenge(defaultChallenge);
        setUsername(userData.username);
        setRequiredCoordinates(defaultCoords);
        const grid = generateGrid(defaultChallenge);
        setGridData(grid);
      } else {
        alert("Invalid session data. Please login again.");
        navigate("/login");
      }
    } else {
      alert("Session expired. Please login again.");
      navigate("/login");
    }
  }, [location.state, navigate]);

  const generateGrid = (challengeData) => {
    const grid = {};
    const rows = ["A", "B", "C", "D", "E", "F"];
    const cols = ["1", "2", "3", "4", "5", "6"];

    // Static grid that matches the backend (same as GRID in security.py)
    const STATIC_GRID = [
      ['57', '92', '41', '86', '63', '22'],
      ['15', '44', '77', '81', '99', '36'],
      ['28', '55', '19', '62', '73', '11'],
      ['64', '48', '35', '97', '20', '54'],
      ['32', '10', '91', '68', '82', '40'],
      ['23', '75', '88', '59', '14', '95']
    ];

    rows.forEach((row, rowIndex) => {
      cols.forEach((col, colIndex) => {
        const position = row + col;
        grid[position] = {
          code: STATIC_GRID[rowIndex][colIndex],
          isChallenge: challengeData && challengeData.hasOwnProperty(position),
        };
      });
    });

    return grid;
  };

  const clearInput = () => {
    setInputValue1("");
    setInputValue2("");
    setInputValue3("");
  };

  const handleSubmit = async () => {
    if (Object.keys(challenge).length === 0) {
      alert("Grid challenge not loaded. Please login again.");
      navigate("/login");
      return;
    }

    if (!inputValue1.trim() || !inputValue2.trim() || !inputValue3.trim()) {
      alert("Please enter all three grid values for the assigned coordinates.");
      return;
    }

    // Combine the three input values with hyphens
    const inputValues = [inputValue1.trim().toUpperCase(), inputValue2.trim().toUpperCase(), inputValue3.trim().toUpperCase()];
    
    // Validate that we have the right number of values
    if (inputValues.length !== requiredCoordinates.length) {
      alert(`Please enter exactly ${requiredCoordinates.length} values for coordinates: ${requiredCoordinates.join(', ')}`);
      return;
    }

    // Create answers object mapping coordinates to user-entered values
    const answers = {};
    requiredCoordinates.forEach((coord, index) => {
      answers[coord] = inputValues[index];
    });

    setLoading(true);

    try {
      // Call the backend API to verify the grid pattern
      const response = await gridAuth({
        username: username,
        answers: answers
      });

      if (response.status === 200) {
        alert("Grid authentication successful! Proceed to face authentication.");
        navigate("/face-auth");
      }
    } catch (error) {
      let errorMessage = "Verification failed. Please try again.";

      if (error.response && error.response.status === 401) {
        errorMessage = "Incorrect values. Please try again.";
      } else if (error.response && error.response.data && error.response.data.error) {
        errorMessage = "Error: " + error.response.data.error;
      }

      alert(errorMessage);
      clearInput();
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="grid-auth-page">
      <div className="grid-auth-container">
        <div className="grid-left-section">
          <h2 className="grid-auth-title">
            Grid Authentication
          </h2>


          <div className="input-section">
            <label className="input-label">
              Grid Values :
            </label>
            <div className="grid-input-container">
              <input
                type="text"
                value={inputValue1}
                onChange={(e) => setInputValue1(e.target.value)}
                placeholder="Value 1"
                className="grid-input-box"
                disabled={loading}
                maxLength="3"
              />
              <span className="hyphen">-</span>
              <input
                type="text"
                value={inputValue2}
                onChange={(e) => setInputValue2(e.target.value)}
                placeholder="Value 2"
                className="grid-input-box"
                disabled={loading}
                maxLength="3"
              />
              <span className="hyphen">-</span>
              <input
                type="text"
                value={inputValue3}
                onChange={(e) => setInputValue3(e.target.value)}
                placeholder="Value 3"
                className="grid-input-box"
                disabled={loading}
                maxLength="3"
              />
            </div>
          </div>

          <div className="action-buttons">
            <button
              onClick={clearInput}
              disabled={loading}
              className="action-button secondary"
            >
              Clear
            </button>
            <button
              onClick={handleSubmit}
              disabled={loading || !inputValue1.trim() || !inputValue2.trim() || !inputValue3.trim()}
              className="action-button primary"
            >
              {loading ? "Verifying..." : "Verify"}
            </button>
          </div>

          <div className="instructions">
            <strong>Instructions:</strong>
            <br />
            • Find the values at those coordinates in the grid
            <br />
            • Enter each value in the corresponding input box
            <br />
            • Example: If coordinates are A1, B3, C5 and their values are ABC, XYZ, 123, enter each value in its respective box
            <br />
            • Click Verify to authenticate
          </div>
        </div>

        <div className="grid-right-section">
          <div className="grid-container">
            <div className="grid-header">
              <div></div>
              {["1", "2", "3", "4", "5", "6"].map((col) => (
                <div key={col} className="grid-column-header">
                  {col}
                </div>
              ))}
            </div>

            {["A", "B", "C", "D", "E", "F"].map((row) => (
              <div key={row} className="grid-row">
                <div className="grid-row-header">
                  {row}
                </div>
                {["1", "2", "3", "4", "5", "6"].map((col) => {
                  const position = row + col;
                  const cell = gridData[position];
                  const isRequired = requiredCoordinates.includes(position);

                  return (
                    <div
                      key={position}
                      className={`grid-cell ${isRequired ? 'grid-cell-highlighted' : ''}`}
                    >
                      <div className="cell-code">
                        {cell?.code || ""}
                      </div>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default GridAuthPage;