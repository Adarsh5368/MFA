// import { useState } from "react";
// import { useNavigate, Link } from "react-router-dom";
// import { loginUser } from "../api/mfa";
// import "../styles/LoginPage.css";

// const LoginPage = () => {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [loading, setLoading] = useState(false);
//   const [errorMsg, setErrorMsg] = useState(""); // 👈 error message
//   const navigate = useNavigate();

//   const handleLogin = async (e) => {
//     e.preventDefault();
//     setLoading(true);
//     setErrorMsg(""); // clear previous errors

//     try {
//       const response = await loginUser(username, password);

//       if (response.status === 200) {
//         const userData = response.data;
//         navigate("/grid-auth", {
//           state: {
//             username,
//             challenge: userData.challenge,
//             userId: userData.userId || userData.user_id
//           }
//         });
//       }
//     } catch (error) {
//       if (error.response?.status === 401) {
//         setErrorMsg("Invalid username or password. Please try again.");
//       } else if (error.response?.data?.message) {
//         setErrorMsg("Login failed: " + error.response.data.message);
//       } else {
//         if (username === "testuser" && password === "1234") {
//           navigate("/grid-auth", {
//             state: {
//               username: "testuser",
//               gridChallenge: "A1-B2-C3",
//               userId: "test-user-id"
//             }
//           });
//         } else {
//           setErrorMsg("Login failed. Please check your credentials or try again later.");
//         }
//       }
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="login-container">
//       <div className="login-form">
//         <h2 className="login-title">Login</h2>
//         <p className="login-subtitle">Welcome back! Please login to your account.</p>
//         <form onSubmit={handleLogin}>
//           <input
//             placeholder="Username"
//             type="text"
//             value={username}
//             onChange={(e) => setUsername(e.target.value)}
//             required
//           />
//           <input
//             placeholder="Password"
//             type="password"
//             value={password}
//             onChange={(e) => setPassword(e.target.value)}
//             required
//           />

//           {errorMsg && <div className="error-message">{errorMsg}</div>}

//           <button type="submit" disabled={loading}>
//             {loading ? "Logging in..." : "Login"}
//           </button>
//         </form>

//         <p>
//           Don't have an account? <Link to="/register">Register here</Link>
//         </p>

//         <div className="test-credentials">
//           <strong>Instructions:</strong><br />
//           1. Register a new account first<br />
//           2. Login with your registered username and password<br />
//         </div>
//       </div>
//     </div>
//   );
// };

// export default LoginPage;
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { loginUser } from "../api/mfa";
import "../styles/LoginPage.css";

const LoginPage = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(""); // 👈 error message
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(""); // clear previous errors

    try {
      const response = await loginUser(username, password);

      if (response.status === 200) {
        const userData = response.data;
        console.log("Login response:", userData); // Debug log
        
        // Handle Flask backend response structure
        if (userData.required_coordinates) {
          // Flask backend returns required_coordinates array
          navigate("/grid-auth", {
            state: {
              username,
              required_coordinates: userData.required_coordinates,
              userId: userData.userId || userData.user_id
            }
          });
        } else if (userData.challenge) {
          // Fallback for different backend structure
          navigate("/grid-auth", {
            state: {
              username,
              challenge: userData.challenge,
              userId: userData.userId || userData.user_id
            }
          });
        } else {
          // Create default challenge if no coordinates provided
          navigate("/grid-auth", {
            state: {
              username,
              required_coordinates: ["A1", "B3", "C5"], // Default for testing
              userId: userData.userId || "default-user"
            }
          });
        }
      }
    } catch (error) {
      console.error("Login error:", error); // Debug log
      
      if (error.response?.status === 401) {
        setErrorMsg("Invalid username or password. Please try again.");
      } else if (error.response?.data?.error) {
        // Flask backend uses 'error' field
        setErrorMsg("Login failed: " + error.response.data.error);
      } else if (error.response?.data?.message) {
        setErrorMsg("Login failed: " + error.response.data.message);
      } else {
        // Test user fallback
        if (username === "testuser" && password === "1234") {
          navigate("/grid-auth", {
            state: {
              username: "testuser",
              required_coordinates: ["A1", "B2", "C3"],
              userId: "test-user-id"
            }
          });
        } else {
          setErrorMsg("Login failed. Please check your credentials or try again later.");
        }
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-form">
        <h2 className="login-title">Login</h2>
        <p className="login-subtitle">Welcome back! Please login to your account.</p>
        <form onSubmit={handleLogin}>
          <div className="input-group">
            <label className="input-label">
              Username <span className="required-star">*</span>
            </label>
            <input
              placeholder="Enter username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          
          <div className="input-group">
            <label className="input-label">
              Password <span className="required-star">*</span>
            </label>
            <input
              placeholder="Enter password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          {errorMsg && <div className="error-message">{errorMsg}</div>}

          <button type="submit" disabled={loading}>
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>

        <p>
          Don't have an account? <Link to="/register">Register here</Link>
        </p>

        <div className="test-credentials">
          <strong>Instructions:</strong><br />
          1. Register a new account first<br />
          2. Login with your registered username and password<br />
          3. Complete grid authentication with assigned coordinates<br />
          4. Register your face using the webcam and wait for confirmation<br />
        </div>
      </div>
    </div>
  );
};

export default LoginPage;