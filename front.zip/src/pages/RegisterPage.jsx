import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { registerUser } from "../api/mfa";
import "../styles/RegisterPage.css";

const RegisterPage = () => {
  const [username, setUsername] = useState("");
  // const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(""); // 👈 for inline error
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();

    if (!username || !password) {
      setErrorMsg("Please fill all fields.");
      return;
    }

    setLoading(true);
    setErrorMsg(""); // Clear previous errors

    try {
      // const response = await registerUser({ username, email, password });
      const response = await registerUser({ username, password });
      if (response.status === 200 || response.status === 201) {
        // Store username in localStorage for later use
        localStorage.setItem('username', username);
        // Navigate to coordinates display page with the assigned coordinates
        const coordinates = response.data.assigned_coordinates;
        navigate("/coordinates", { state: { coordinates } });
      }
    } catch (error) {
      const message = error.response?.data?.error || "Registration failed.";
      setErrorMsg(message);
      console.error("Registration error:", message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="register-container">
      <div className="register-form">
        <h2>Create Account</h2>
        <p>Join us by creating your account</p>

        <form onSubmit={handleRegister}>
          <div className="input-group">
            <label className="input-label">
              Username <span className="required-star">*</span>
            </label>
            <input
              type="text"
              placeholder="Enter username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          
          {/* <div className="input-group">
            <label className="input-label">Email</label>
            <input
              type="email"
              placeholder="Enter email (optional)"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div> */}
          
          <div className="input-group">
            <label className="input-label">
              Password <span className="required-star">*</span>
            </label>
            <input
              type="password"
              placeholder="Enter password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          {errorMsg && <div className="error-message">{errorMsg}</div>}

          <button type="submit" disabled={loading}>
            {loading ? "Registering..." : "Register Account"}
          </button>
        </form>

        <p>
          Already have an account? <Link to="/login">Login here</Link>
        </p>
      </div>
    </div>
  );
};

export default RegisterPage;
