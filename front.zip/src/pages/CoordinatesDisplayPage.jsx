import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "../styles/CoordinatesDisplayPage.css";

const CoordinatesDisplayPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const coordinates = location.state?.coordinates;

  const faceRegistered = location.state?.faceRegistered || false;
  const handleContinue = () => {
    navigate("/login");
  };
  const handleNextStep = () => {
    navigate("/face-register", { state: { coordinates } });
  };

  // If no coordinates were passed, redirect to register
  if (!coordinates) {
    navigate("/register");
    return null;
  }

  return (
    <div className="coordinates-container">
      <div className="coordinates-card">
        <div className="success-icon">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="10" stroke="#00ff88" strokeWidth="2"/>
            <path d="m9 12 2 2 4-4" stroke="#00ff88" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        
        <h2>Registration Successful!</h2>
        <p className="success-message">
          Your account has been created successfully. Please save your assigned grid coordinates below.
        </p>

        <div className="coordinates-section">
          <h3>Your Assigned Grid Coordinates</h3>
          <div className="coordinates-grid">
            {Object.entries(coordinates).map(([position, value]) => (
              <div key={position} className="coordinate-item">
                <span className="value">{value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="important-note">
          <div className="note-icon">⚠️</div>
          <p>
            <strong>Important:</strong> Please memorize or securely save these coordinates. 
            You will need to enter the values for these specific positions during login.
          </p>
        </div>

        {!faceRegistered ? (
          <button className="next-step-btn" onClick={handleNextStep}>
            Next Step: Register Face
          </button>
        ) : (
          <button className="continue-btn" onClick={handleContinue}>
            Continue to Login
          </button>
        )}
      </div>
    </div>
  );
};

export default CoordinatesDisplayPage;
