// ...existing code...

import React, { useRef, useState } from "react";
import Webcam from "react-webcam";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "../styles/FaceAuthPage.css";

const FaceAuthPage = () => {
  const webcamRef = useRef(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [isFaceVerified, setIsFaceVerified] = useState(false);
  const navigate = useNavigate();

  const handleFaceAuth = async () => {
    setLoading(true);
    setError("");
    const username = localStorage.getItem("username");
    if (!username) {
      setError("No username found. Please log in or register first.");
      setLoading(false);
      return;
    }
    const imageSrc = webcamRef.current.getScreenshot();
    if (!imageSrc) {
      setError("Could not capture image.");
      setLoading(false);
      return;
    }
    // Convert base64 to blob
    const byteString = atob(imageSrc.split(",")[1]);
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([ab], { type: "image/jpeg" });
    const formData = new FormData();
    formData.append("username", username);
    formData.append("file", blob, "face.jpg");
    try {
      const response = await axios.post("http://localhost:8000/face/verify", formData);
      if (response.data.token) {
        localStorage.setItem("access_token", response.data.token);
        setIsFaceVerified(true);
        setTimeout(() => {
          navigate("/home");
        }, 1500);
      } else {
        setError(response.data.msg || "Face authentication failed.");
      }
    } catch (err) {
      setError(err.response?.data?.msg || "Face authentication failed.");
    }
    setLoading(false);
  };

  return (
    <div className="face-auth-container">
      <div className="face-auth-card">
        <h2 className="face-auth-title">Face Authentication</h2>
        <Webcam
          audio={false}
          ref={webcamRef}
          screenshotFormat="image/jpeg"
          className="face-auth-video webcam-view"
        />
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', width: '100%' }}>
          <button onClick={handleFaceAuth} disabled={loading} className="face-auth-btn">
            {loading ? "Authenticating..." : "Authenticate Face"}
          </button>
        </div>
        <p className={`face-auth-status ${isFaceVerified ? "verified" : "waiting"}`}>
          <span className="status-icon">
            {isFaceVerified ? "✅" : "🔒"}
          </span>
          {isFaceVerified ? "Face authentication successful!" : error ? error : "Waiting for face match..."}
        </p>
      </div>
    </div>
  );
};

export default FaceAuthPage;
