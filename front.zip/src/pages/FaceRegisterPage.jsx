import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Webcam from 'react-webcam';
import '../styles/FaceRegisterPage.css';

const FaceRegisterPage = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [cameraOpen, setCameraOpen] = useState(true);
  const navigate = useNavigate();
  const webcamRef = React.useRef(null);

  const handleFaceRegister = async () => {
    setLoading(true);
    setError('');
    const imageSrc = webcamRef.current.getScreenshot();
    if (!imageSrc) {
      setError('Could not capture image.');
      setLoading(false);
      return;
    }
    // Convert base64 to blob
    const byteString = atob(imageSrc.split(',')[1]);
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([ab], { type: 'image/jpeg' });
    const formData = new FormData();
    formData.append('username', localStorage.getItem('username'));
    formData.append('file', blob, 'face.jpg');
    try {
      const response = await axios.post('http://localhost:8000/face/enroll', formData);
      if (response.status === 200) {
        alert('Face registered successfully!');
        navigate('/login');
      } else {
        setError(response.data.msg || 'Face registration failed.');
      }
    } catch (err) {
      setError(err.response?.data?.msg || 'Face registration failed.');
    }
    setLoading(false);
  };

  return (
    <div className="face-register-container">
      <div className="face-register-card">
        <h2 className="face-register-title">Face Registration</h2>
        {cameraOpen && (
          <Webcam
            audio={false}
            ref={webcamRef}
            screenshotFormat="image/jpeg"
            className="webcam-view"
          />
        )}
        <button
          onClick={() => setCameraOpen((prev) => !prev)}
          className="face-register-btn"
          style={{ marginBottom: '20px' }}
        >
          {cameraOpen ? 'Close Camera' : 'Open Camera'}
        </button>
        <button onClick={handleFaceRegister} disabled={loading || !cameraOpen} className="face-register-btn">
          {loading ? 'Registering...' : 'Register Face'}
        </button>
        {error && <div className="error-msg">{error}</div>}
      </div>
    </div>
  );
};

export default FaceRegisterPage;
